import { routes } from "./app.routes";
import { UsersComponent } from "./users/users.component";

describe('Routes',()=>{
    it('Should contain /users route in routes',()=>{
        expect(routes).toContain({ path: 'users', component: UsersComponent });
    });
});