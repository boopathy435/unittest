
export function compute(number) {
  if (number < 0)
    return 0; 

  return number + 1;
}
