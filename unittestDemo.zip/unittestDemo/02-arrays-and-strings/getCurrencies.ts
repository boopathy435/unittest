
export function getCurrencies() { 
  return ['USD', 'AUD', 'EUR'];
}